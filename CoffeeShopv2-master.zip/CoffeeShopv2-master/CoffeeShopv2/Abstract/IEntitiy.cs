﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoffeeShopv2.Abstract
{
   public interface IEntitiy
    {
    }
}
