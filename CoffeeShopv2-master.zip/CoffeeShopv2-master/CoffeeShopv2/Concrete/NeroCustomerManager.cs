﻿using System;
using System.Collections.Generic;
using System.Text;
using CoffeeShopv2.Abstract;

namespace CoffeeShopv2.Concrete
{
    public class NeroCustomerManager : BaseCustomerManager
    {

    }
}
