﻿namespace CoffeeShopv2.Concrete
{
    public class StarbucksCustomerManagerBase
    {
    }
}