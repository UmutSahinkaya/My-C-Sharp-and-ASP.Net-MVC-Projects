# Dizilerin Hazır Methodları
## Array.Sort()
* Dizi üzerinden sıralama işlemi yapar.
* Eğer string bir dizi ise A'dan Z'ye bir sıralama yapar.
* ORN: Array.Sort(sayiDizisi);
## Array.Clear()
* Dizinin belirtilen elemenlarını varsayılan değerine getirir.Yani dizi numeric bir dizi ise 0 olarak set eder.
* ORN: Array.Clear(sayiDizisi,2,2); -> 2. indexden başlayarak 2 tane elemanı temizler.!!
## Array.Reverse()
* Dizinin ortasını belirleyerek elemanlarını Aynalar gibi düşünebilirsiniz,bir diğer söyleyiş ile diziyi ters çevirir.
* Array.Reverse(sayiDizisi);=> {1,3,4,9,8,7} -> {7,8,9,4,3,1}
## Array.IndexOf()
* Verilen dizinin istenilen indisteki elemanını getirir.
* ORN: Array.IndexOf(sayiDizisi,7);
## Array.Resize()
* Dizileri yeniden boyutlandırmak için kullanılır.
```C#
int[] sayiDizisi ={1,3,4,9,8,7};
Array.Resize<int>(ref sayiDizisi,12);
sayiDizisi[6]=10;
```
* Yukarıdaki örnekte başlangıçta 6 tane elemanı olan sayiDizisi Resize methodu ile birlikte 12 elemanlı hale getirildi.Daha sonra 7.elamana 10 değeri atandı.Diğer boş olan indislere de 0 değeri atandı.
 ```C#
int[] sayiDizisi ={1,3,4,9,8,7};
Array.Resize<int>(ref sayiDizisi,3);
```
* Bu kod parçasıyla da Resize methodu kullanılarak sondaki 3 elemanı yok ederek dizi 3 indisli hale getirildi ve son hali ise {1,3,4} oldu.