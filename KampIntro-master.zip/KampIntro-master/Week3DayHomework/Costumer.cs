﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week3DayHomework
{
    class Customer
    {
        public int id { get; set; }
        public String firstName { get; set; }
        public String lastName { get; set; }
        public int cAge { get; set; }
        public String identityNumber { get; set; }
    }
}
