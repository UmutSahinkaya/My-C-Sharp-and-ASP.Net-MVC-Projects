﻿namespace InterfacesDemo
{
    interface IWorker
    {
        public void Work();
    }
}
