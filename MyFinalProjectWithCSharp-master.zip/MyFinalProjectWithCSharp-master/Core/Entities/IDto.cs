﻿namespace Core
{
    public interface IDto
    {
    }
}