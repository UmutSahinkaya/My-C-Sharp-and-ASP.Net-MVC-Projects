﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameProjectDemoV2.Abstract
{
    public interface IEntitiy
    {
    }
}
