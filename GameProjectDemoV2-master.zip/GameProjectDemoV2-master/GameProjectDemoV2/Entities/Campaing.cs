﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameProjectDemoV2.Entities
{
    public class Campaing
    {
        public int Id { get; set; }
        public string CampaingName { get; set; }
        public double CampaingDiscount { get; set; }
    }
}
